﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnManager : MonoBehaviour
{

	void Start () {
		
	}

    void Spawn_Wave()
    {

    }
	
    void Spawn_Enemy(int _enemyID)
    {

    }
}
