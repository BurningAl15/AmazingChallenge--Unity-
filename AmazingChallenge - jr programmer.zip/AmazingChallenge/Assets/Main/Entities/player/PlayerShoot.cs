﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerShoot : MonoBehaviour {

    GameObject bulletPrefab;
	
	void Update ()
    {
		
	}

    void Shoot()
    {
        Instantiate(bulletPrefab);
    }
}
