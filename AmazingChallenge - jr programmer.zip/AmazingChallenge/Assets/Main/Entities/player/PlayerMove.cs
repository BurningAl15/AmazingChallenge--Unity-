﻿///Amazing Games Studio SAC - 2018.
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
1. Identificar deficiencias en el codigo.
2. Corregir las deficiencias segun corresponda.
3. Mantener el codigo ordenado y facil de entender.
*/
public class PlayerMove : MonoBehaviour
{
    float moveSpeed = 10f;

	void Update ()
    {
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");

        Move( new Vector3(/* */) );
	}

    void Move(Vector3 _direction)
    {
        GetComponent<Rigidbody>().velocity = _direction * moveSpeed;

    }
}
